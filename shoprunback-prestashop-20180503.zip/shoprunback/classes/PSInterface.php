<?php

interface PSInterface
{
    static function getTableName();
    static function getIdColumnName();
    static function getIdentifier();
}