document.addEventListener("DOMContentLoaded", function(event) {
  var tabs = document.getElementsByClassName('icon-AdminShoprunback');

  for (var i = 0; i < tabs.length; i++) {
    tabs[i].classList.add('icon-exchange');
  }
});