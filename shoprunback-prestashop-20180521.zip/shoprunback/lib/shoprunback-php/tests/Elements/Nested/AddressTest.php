<?php

namespace Tests\Elements\Nested;

use \Tests\Elements\Nested\BaseNestedTest;

use \Shoprunback\Elements\Address;

final class AddressTest extends BaseNestedTest
{
    use \Tests\Elements\AddressTrait;
}