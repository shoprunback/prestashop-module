
# Abstract

Write here an summary of the feature request (less than 3 lines)

# Details

Write here all the details of the request. 
You can provide images too.

If you don't have details yet, leave blank and come back later to fill it.

# Requester

Write here for who this feature is for (which retailer, which customer, which employee, …)
