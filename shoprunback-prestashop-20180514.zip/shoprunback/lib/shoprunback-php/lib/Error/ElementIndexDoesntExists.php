<?php

namespace Shoprunback\Error;

class ElementIndexDoesntExists extends Error
{
}