<?php

namespace Shoprunback\Error;

class ElementCannotBeCreated extends Error
{
}