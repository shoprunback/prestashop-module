<?php

namespace Shoprunback\Error;

class UnknownApiToken extends Error
{
}